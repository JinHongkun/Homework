# WORK SUMMARY 
In this work,I have finished this program which is an industrial example of a rankine cycle by myself for the first time in this course so I faced many problems during my work.

The programs consists of many different classes and what counts is that the classes must be imported correctly.
At first, I only imported the document so it would not simulate right as I did not import their content.So I need to use

	import Boiler as Boiler
if I want to use its function directly.Otherwise, I should use syntax like 

	Boiler.Boiler(10,0) 
to use its function if I just use

	import Boiler

The second problem I have overcomed is the caculation of the thermodynamics.I forgot the heated added by the reheat system so that the efficiency tended to be lower.

After accomplishing this work,I have realized that only if I do the work step by step can I find where my mistakes are and improve my skills quickly.  
	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;by JinHongkun  
	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;2017.4.15