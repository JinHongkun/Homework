from .Node import *


class ClosedHeater():

   
    energy = 'internel'
    def __init__(self,name,inletExtractedWaterNode,inletNode,exitSaturatedLiquidNode,exitNode):
       
        self.inletExtractedWaterNode = inletExtractedWaterNode
        self.exitNode = exitNode
        self.inletNode = inletNode
        self.exitSaturatedLiquidNode = exitSaturatedLiquidNode
        self.name = name
        
        
        self.heatExtracted = 0
        self.QExtracted = 0
        
        self.typeStr = 'CLOSEDHEATER'
        
        self.fdotok = False
        
    def state(self,nodes):
        pass
    
    def fdot(self, nodes):
        if (self.fdotok == False):
            try:
                if (nodes[self.exitNode].fdot != None):
                    self.heatAdded= nodes[self.exitNode].fdot *(nodes[self.exitNode].h - nodes[self.inletNode].h)
                    self.heatExtracted = self.heatAdded      
                    nodes[self.inletExtractedWaterNode].fdot = self.heatExtracted / \
                        (nodes[self.inletExtractedWaterNode].h - nodes[self.exitSaturatedLiquidNode].h)
                    nodes[self.inletNode].fdot = nodes[self.exitNode].fdot
                    nodes[self.exitSaturatedLiquidNode].fdot=nodes[self.inletExtractedWaterNode].fdot

                self.fdotok = (nodes[self.exitNode].fdot != None)
                self.fdotok = self.fdotok and (nodes[self.inletNode_fw].fdot != None)
                self.fdotok = self.fdotok and (nodes[self.inletExtractedWaterNode].fdot != None)
                self.fdotok = self.fdotok and (nodes[self.exitSaturatedLiquidNode].fdot != None)
            except:
                self.fdotok = False
                
    def simulate(self,nodes):
        self.heatAdded= nodes[self.exitNode].fdot *(nodes[self.exitNode].h - nodes[self.inletNode].h)
        self.heatExtracted = self.heatAdded  
        
    def sm_energy(self, nodes):
        self.QExtracted = nodes[self.exitNode].mdot *(nodes[self.exitNode].h - nodes[self.inletNode].h)
        self.QExtracted /= (3600.0 * 1000.0)
        self.QAdded = self.QExtracted
        
    def export(self, nodes):
        result = '\n' + self.name
        result += '\n' + Node.nodetitle
        result += '\n' + nodes[self.inletExtractedWaterNode].__str__()
        result += '\n' + nodes[self.inletNode].__str__()
        result += '\n' + nodes[self.exitSaturatedLiquidNode].__str__()
        result += '\n' + nodes[self.exitNode].__str__()
        
        result += '\nheatAdded(kJ/kg) \t%.2f' % self.heatAdded
        result += '\nheatExtracted(kJ/kg) \t%.2f' % self.heatExtracted
        result += '\nQAdded(MW) \t%.2f' % self.QAdded
        result += '\nQExtracted(MW)  \t%.2f' % self.QExtracted
        return result
