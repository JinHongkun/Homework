from .Node import *

class Pump():
    energy = "workRequired"
    
    def __init__(self,name,inletNode, exitNode):
        
        self.inletNode = inletNode
        self.exitNode = exitNode
        self.name=name
        self.typeStr = "PUMP"
     
        self.fdotok = False

    def state(self,nodes):
        nodes[self.exitNode].s = nodes[self.inletNode].s
        nodes[self.inletNode].s = nodes[self.exitNode].s
        nodes[self.exitNode].ps()
        nodes[self.inletNode].ps()
        
    def fdot(self, nodes):
        if (self.fdotok == False):
            try:
                if (nodes[self.inletNode].fdot != None):
                    nodes[self.exitNode].fdot = nodes[self.inletNode].fdot
                elif (nodes[self.exitNode].fdot != None):
                    nodes[self.inletNode].fdot = nodes[self.exitNode].fdot

                self.fdotok = nodes[self.exitNode].fdot != None
                self.fdotok = self.fdotok and (nodes[self.inletNode].fdot != None)
            except:
                self.fdotok == False

    def simulate(self,nodes):
        self.workRequired = nodes[self.inletNode].fdot *(nodes[self.exitNode].h - nodes[self.inletNode].h)
    
    def sm_energy(self, nodes):
        self.WRequired = nodes[self.inletNode].mdot * \
            (nodes[self.exitNode].h - nodes[self.inletNode].h)
        self.WRequired /= (3600.0 * 1000.0)
    
    def export(self, nodes):
        result = '\n' + self.name
        result += '\n' + Node.nodetitle
        result += '\n' + nodes[self.inletNode].__str__()
        result += '\n' + nodes[self.exitNode].__str__()

        result += '\nworkRequired(kJ/kg): \t%.2f' % self.workRequired
        result += '\nWRequired(MW): \t%.2f' % self.WRequired
        return result
