from .Node import *

class OpenHeater():

    energy = 'internel'

    def __init__(self,name, inletExtractedWaterNode,inletNode,exitNode,inletCondensateNode=None):
        
        self.inletExtractedWaterNode = inletExtractedWaterNode
        self.inletNode=inletNode
        self.inletCondensateNode=inletCondensateNode
        self.exitNode=exitNode
        self.name = name
        
        self.heatExtracted = 0
        self.QExtracted = 0

        self.typeStr = 'OPENHEATER'
      
        self.fdotok = False
    
    def state(self, nodes):
        pass
    
    def fdot(self, nodes):
        if (self.fdotok == False):
            try:
                if (nodes[self.exitNode].fdot != None):
                    if (self.inletCondensateNode!= None):
                        self.heatExtractedFromCondensate = nodes[self.inletCondensateNode].fdot *\
                        (nodes[self.inletCondensateNode].h- nodes[self.exitNode].h )
                        nodes[self.inletExtractedWaterNode].fdot=((1-nodes[self.inletCondensateNode].fdot)*(nodes[self.exitNode].h- nodes[self.inletNode].h)-self.heatExtractedFromCondensate)/(nodes[self.inletExtractedWaterNode].h- nodes[self.exitNode].h+nodes[self.exitNode].h- nodes[self.inletNode].h)
                        nodes[self.inletNode].fdot = 1-nodes[self.inletCondensateNode].fdot- nodes[self.inletExtractedWaterNode].fdo
                        nodes[self.exitNode].fdot =  nodes[self.inletNode].fdot+nodes[self.inletCondensateNode].fdot+nodes[self.inletExtractedWaterNode].fdot
                    else:
                        self.heatAdded = nodes[self.exitNode].fdot * \
                        (nodes[self.exitNode].h - nodes[self.inletNode].h)
                        self.heatExtracted = self.heatAdded
                        nodes[self.inletExtractedWaterNode].fdot = self.heatExtracted / \
                        (nodes[self.inletExtractedWaterNode].h - nodes[self.inletNode].h)
                        nodes[self.inletNode].fdot = nodes[self.exitNode].fdot - nodes[self.inletExtractedWaterNode].fdot

                
                self.fdotok = (nodes[self.exitNode].fdot != None)
                self.fdotok = self.fdotok and (nodes[self.inletCondensateNode].fdot != None)
                self.fdotok = self.fdotok and (nodes[self.inletNode].fdot != None)
                self.fdotok = self.fdotok and (nodes[self.inletExtractedWaterNodeNode].fdot != None)
            except:
                self.fdotok = False
    
    def simulate(self,nodes):
        if (self.inletCondensateNode!= None):
            self.heatAdded =nodes[self.inletNode].fdot *( nodes[self.exitNode].h- nodes[self.inletNode].h )
        else:
            self.heatAdded =nodes[self.exitNode].fdot *( nodes[self.exitNode].h- nodes[self.inletNode].h )
        self.heatExtracted = self.heatAdded
        
        
        
    def sm_energy(self, nodes):
        if (self.inletCondensateNode!= None):
            self.QExtracted = nodes[self.inletNode].mdot *( nodes[self.exitNode].h- nodes[self.inletNode].h )
        else:
            self.QExtracted = nodes[self.exitNode].mdot *( nodes[self.exitNode].h- nodes[self.inletNode].h )
        self.QExtracted /= (3600.0 * 1000.0)
        self.QAdded = self.QExtracted
        
        
    
    def export(self, nodes):
        result = '\n' + self.name
        result += '\n' + Node.nodetitle
        result += '\n' + nodes[self.inletExtractedWaterNode].__str__()
        result += '\n' + nodes[self.inletNode].__str__()
        result += '\n' + nodes[self.exitNode].__str__()
        if  self.inletCondensateNode!=None:
            result+='\n'+nodes[self.inletCondensateNode].__str__()

        result += '\nheatAdded(kJ/kg) \t%.2f' % self.heatAdded
        result += '\nheatExtracted(kJ/kg) \t%.2f' % self.heatExtracted
        result += '\nQAdded(MW) \t%.2f' % self.QAdded
        result += '\nQExtracted(MW)  \t%.2f' % self.QExtracted
        return result
