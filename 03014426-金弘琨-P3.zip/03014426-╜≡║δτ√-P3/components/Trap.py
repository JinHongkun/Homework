from .Node import *


class Trap():
    energy = 'None'
    
    def __init__(self,name,inletNode, exitNode):
        
        self.inletNode = inletNode
        self.exitNode = exitNode
        self.name = name
        self.fdotok= False
    def state(self,nodes):
        
        nodes[self.exitNode].h = nodes[self.inletNode].h
       
        nodes[self.exitNode].ph()
        
    def fdot(self, nodes):
        if (self.fdotok == False):
            try:
                if (nodes[self.inletNode].fdot != None):
                    nodes[self.exitNode].fdot = nodes[self.inletNode].fdot
                elif (nodes[self.exitNode].fdot != None):
                    nodes[self.inletNode].fdot = nodes[self.exitNode].fdot

                self.fdotok = nodes[self.exitNode].fdot != None
                self.fdotok = self.fdotok and (nodes[self.inletNode].fdot != None)
            except:
                self.fdotok == False
                
    def simulate(self,nodes):
        pass
    
    def sm_energy(self, nodes):
        pass
        
    def export(self, nodes):
        result = '\n' + self.name
        result += '\n' + Node.nodetitle
        result += '\n' + nodes[self.inletNode].__str__()
        result += '\n' + nodes[self.exitNode].__str__()
        return result
        
