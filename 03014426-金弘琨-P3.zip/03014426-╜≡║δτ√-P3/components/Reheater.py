from .Node import *

class Reheater():
    energy = "heatAdded"
    def __init__(self,name,inletNode, exitNode):
      
        self.inletNode = inletNode
        self.exitNode = exitNode
        self.name=name
        self.typeStr = 'REHEATER'
        
        self.fdotok = False
        
    def state(self,nodes):
        pass
    def fdot(self, nodes):
        if (self.fdotok == False):
            try:
                if (nodes[self.inletNode].fdot != None):
                    nodes[self.exitNode].fdot = nodes[self.inletNode].fdot
                elif (nodes[self.exitNode].fdot != None):
                    nodes[self.inletNode].fdot = nodes[self.exitNode].fdot

                self.fdotok = nodes[self.exitNode].fdot != None
                self.fdotok = self.fdotok and (nodes[self.inletNode].fdot != None)
            except:
                self.fdotok == False
                
    def simulate(self, nodes):
        self.heatAdded = nodes[self.inletNode].fdot * \
            (nodes[self.exitNode].h - nodes[self.inletNode].h)
            
    def sm_energy(self, nodes):
        
        self.QAdded = nodes[self.inletNode].mdot * \
            (nodes[self.exitNode].h - nodes[self.inletNode].h)
        self.QAdded /= (3600.0 * 1000.0)
        
    def export(self, nodes):
        result = '\n' + self.name
        result += '\n' + Node.nodetitle
        result += '\n' + nodes[self.inletNode].__str__()
        result += '\n' + nodes[self.exitNode].__str__()
        result += '\nheatAdded(kJ/kg) \t%.2f \nQAdded(MW) \t%.2f' % (
            self.heatAdded, self.QAdded)
        return result
