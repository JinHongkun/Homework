from .Node import *
import seuif97

class Turbine():

    energy = 'workExtracted'
    def __init__(self, name,inletNode, exitNode,extractedNode=None,ef=100.0):
        self.inletNode = inletNode
        self.extractedNode = extractedNode
        self.exitNode = exitNode
        self.name = name
        self.ef=ef/100.0

        self.fdotok=False
        
    def state(self,nodes):
       
        if self.ef==1.0:
            nodes[self.exitNode].s =nodes[self.inletNode].s
            nodes[self.exitNode].ps()
        else:
            isoh=seuif97.ps2h(nodes[self.exitNode].p,nodes[self.inletNode].s)
            nodes[self.exitNode].h=nodes[self.inletNode].h-self.ef*(nodes[self.inletNode].h-isoh)
            nodes[self.exitNode].ph()
        if self.extractedNode!=None:
           if self.ef==1.0:
              nodes[self.extractedNode].s =nodes[self.inletNode].s
              nodes[self.extractedNode].ps()
           else:
              isoh=seuif97.ps2h(nodes[self.extractedNode].p,nodes[self.inletNode].s)
              nodes[self.extractedNode].h=nodes[self.inletNode].h-self.ef*(nodes[self.inletNode].h-isoh)
              nodes[self.extractedNode].ph()
              
              isoh=seuif97.ps2h(nodes[self.exitNode].p,nodes[self.extractedNode].s)
              nodes[self.exitNode].h=nodes[self.extractedNode].h-self.ef*(nodes[self.extractedNode].h-isoh)
              nodes[self.exitNode].ph()
           
            
    def fdot(self, nodes):
        if (self.fdotok==False):
           try:
                if  self.extractedNode!=None:
                    nodes[self.exitNode].fdot=nodes[self.inletNode].fdot-nodes[self.extractedNode].fdot
                    nodes[self.extractedNode].fdot=nodes[self.inletNode].fdot-nodes[self.exitNode].fdot
                    nodes[self.exitNode].fdot=nodes[self.inletNode].fdot-nodes[self.extractedNode].fdot
                else:    
                    nodes[self.exitNode].fdot=nodes[self.inletNode].fdot
                
                self.fdotok= nodes[self.exitNode].fdot!=None
                self.fdotok= self.fdotok and (nodes[self.inletNode].fdot !=None)
                self.fdotok= self.fdotok and (nodes[self.extractedNode].fdot !=None)

           except:
                self.fdotok=False 
                
    def simulate(self,nodes):
        self.workExtracted =0
        if  self.extractedNode!=None:
             self.workExtracted = nodes[self.extractedNode].fdot * (nodes[self.inletNode].h - nodes[self.extractedNode].h) 
        self.workExtracted  +=  nodes[self.exitNode].fdot *( nodes[self.inletNode].h -  nodes[self.exitNode].h)    
    
    def sm_energy(self, nodes):
        self.WExtracted =0
      
        if  self.extractedNode!=None:
            self.WExtracted = nodes[self.extractedNode].mdot * (nodes[self.inletNode].h - nodes[self.extractedNode].h) 
         
        self.WExtracted  +=  nodes[self.exitNode].mdot *( nodes[self.inletNode].h -  nodes[self.exitNode].h)  
       
        self.WExtracted /=(3600.0*1000.0)
        
    
                
    def export(self,nodes):
        result='\n'+self.name 
        result+='\n'+Node.nodetitle
        result+='\n'+nodes[self.inletNode].__str__()
        result+='\n'+nodes[self.exitNode].__str__()
        if  self.extractedNode!=None:
            result+='\n'+nodes[self.extractedNode].__str__()

        result+='\nworkExtracted(kJ/kg): \t%.2f \nWExtracted(MW): \t%.2f'%(self.workExtracted,self.WExtracted)
        return result
