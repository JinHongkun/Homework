from .Node import *

class Condenser:
    energy = "heatExtracted"

    def __init__(self,name,inletNode, exitNode):
       
        self.inletNode = inletNode
        self.exitNode = exitNode
        self.name = name
        self.typeStr = 'CONDENSER'
     
        self.fdotok = False
        
    def state(self, nodes):
        pass
    
    
    def fdot(self, nodes):
        if (self.fdotok == False):
            try:
                if (nodes[self.inletNode].fdot != None):
                    nodes[self.exitNode].fdot = nodes[self.inletNode].fdot
                elif (nodes[self.exitNode].fdot != None):
                    nodes[self.inletNode].fdot = nodes[self.exitNode].fdot

                self.fdotok = nodes[self.exitNode].fdot != None
                self.fdotok = self.fdotok and (nodes[self.inletNode].fdot != None)
            except:
                self.fdotok == False
                
    def simulate(self,nodes):
        self.heatExtracted = nodes[self.inletNode].fdot*(nodes[self.inletNode].h - nodes[self.exitNode].h)

    def sm_energy(self, nodes):
        self.QExtracted = nodes[self.inletNode].mdot * \
            (nodes[self.inletNode].h - nodes[self.exitNode].h)
        self.QExtracted /= (3600.0 * 1000.0)
    
    def export(self, nodes):
        result = '\n' + self.name
        result += '\n' + Node.nodetitle
        result += '\n' + nodes[self.inletNode].__str__()
        result += '\n' + nodes[self.exitNode].__str__()
        result += '\nheatExtracted(kJ/kg)  \t%.2f \nQExtracted(MW): \t%.2f' % (
            self.heatExtracted, self.QExtracted)
        return result
