import glob
import rankine_cycle as rkc

nds_filesname_str=r'./cyclefile/rankine8[0-9]-nds.csv'
dev_filesname_str=r'./cyclefile/rankine8[0-9]-dev.csv'
    
nds_filesname=glob.glob(nds_filesname_str)
dev_filesname=glob.glob(dev_filesname_str)

cycle=[]
for i in range(len(nds_filesname)):
    cycle.append(rkc.SimRankineCycle(nds_filesname[i],dev_filesname[i]))
    cycle[i].CycleSimulator()
    
Wcycledot = 100
for i in range(len(nds_filesname)):
    cycle[i].SpecifiedNetOutputPowerSimulatorAndOutput(Wcycledot)      
    
    
     
