import csv
import sys
import numpy as np
from components.Node import Node
from components.Turbine import Turbine
from components.Pump import Pump
from components.Condenser import Condenser
from components.Boiler import Boiler
from components.ClosedHeater import ClosedHeater
from components.Reheater import Reheater
from components.Trap import Trap
from components.OpenHeater import OpenHeater



def read_nodesfile(filename):
    """ nodes in the  csv file"""
    countNodes = len(open(filename, 'r').readlines()) - 1
    nodes = [None for i in range(countNodes)]
    csvfile = open(filename, 'r')
    reader = csv.DictReader(csvfile)
    for line in reader:
        i = int(line['NID'])
        nodes[i] = Node(line['NAME'], i)
        try:
            nodes[i].p = float(line['p'])
        except:
            nodes[i].p = None
        try:
            nodes[i].t = float(line['t'])
        except:
            nodes[i].t = None
        try:
            nodes[i].x = float(line['x'])
        except:
            nodes[i].x = None
        try:
            nodes[i].fdot = float(line['fdot'])
        except:
            nodes[i].fdot = None
        if line['p'] != '' and line['t'] != '':
            nodes[i].pt()
        elif line['p'] != '' and line['x'] != '':
            nodes[i].px()
        elif line['t'] != '' and line['x'] != '':
            nodes[i].tx()
            
    csvfile.close()
    return nodes, countNodes



def read_devicefile(filename):
    devFile = open(filename, 'r')
    discardHeader = devFile.readline()
    Comps = {}
    i = 0
    begId = 2
    for line in devFile:
        dev = line.split(',')
         
        if dev[1] == "BOILER":
            Comps[dev[0]] = Boiler(dev[0], int(
                dev[begId]),  int(dev[begId + 1]))
        elif dev[1] == "HIGHPRESSURETURBINE":
            Comps[dev[0]] = Turbine(
                dev[0], int(dev[begId]), int(dev[begId + 1]),int(dev[begId + 2]))
        elif dev[1] == "REHEATER":
            Comps[dev[0]] = Reheater(
                dev[0], int(dev[begId]), int(dev[begId + 1]))
        elif dev[1] == "LOWPRESSURETURBINE":
            Comps[dev[0]] = Turbine(
                dev[0], int(dev[begId]), int(dev[begId + 1]),int(dev[begId + 2]))
        elif dev[1] == "CONDENSER":
            Comps[dev[0]] = Condenser(dev[0], int(
                dev[begId]),  int(dev[begId + 1]))
        elif dev[1] == "PUMP1":
            Comps[dev[0]] = Pump(dev[0], int(
                dev[begId]),  int(dev[begId + 1]))
        elif dev[1] == "CLOSEDHEATER":
            Comps[dev[0]] = ClosedHeater(dev[0], int(
                dev[begId]),  int(dev[begId + 1]),int(dev[begId + 2]),int(dev[begId + 3]))
        elif dev[1] == "TRAP":
            Comps[dev[0]] = Trap(dev[0], int(
                dev[begId]),  int(dev[begId + 1]))
        elif dev[1] == "OPENHEATER":
            Comps[dev[0]] = OpenHeater(dev[0], int(
                dev[begId]),  int(dev[begId + 1]),int(dev[begId + 2]),int(dev[begId + 3]))
        elif dev[1] == "PUMP2":
            Comps[dev[0]] = Pump(dev[0], int(
                dev[begId]),  int(dev[begId + 1]))
        elif dev[1] == "TURBINE-EX1":
            Comps[dev[0]] = Turbine(dev[0], int(dev[begId]),  int(
                dev[begId + 1]), int(dev[begId + 2]), ef=float(dev[5]))
        elif dev[1] == "TURBINE-EX0":
            Comps[dev[0]] = Turbine(dev[0], int(
                dev[begId]),  int(dev[begId + 1]))
        elif dev[1] == "PUMP":
            Comps[dev[0]] = Pump(dev[0], int(
                dev[begId]),  int(dev[begId + 1]))
        elif dev[1] == "OH-FEEDWATER-DW0":
            Comps[dev[0]] = OpenHeater(dev[0], int(
                dev[begId]), int(dev[begId + 1]), int(dev[begId + 2]))
        
        
     
        i = i + 1
        
    devFile.close()
    
    DevNum = i
    return Comps, DevNum


class RankineCycle(object):
    def __init__(self, name):
        self.name = name
        self.nodes = []
        self.Comps = {}
        self.NodeNum = 0
        self.DevNum = 0
        self.totalworkExtracted = 0
        self.totalworkRequired = 0
        self.totalWExtracted = 0
        self.totalWRequired = 0

        self.totalheatAdded = 0
        self.totalQAdded = 0

        self.netpoweroutput = 0
        self.efficiency = 100.0

        self.mdot = None
        self.Wcycledot = None
        
        self.fdotok = False
            
    def addNodes(self, filename):
        self.nodes, self.NodeNum = read_nodesfile(filename)
 
    def addComponent(self, filename):
        self.Comps, self.DevNum = read_devicefile(filename)
    
    def componentState(self):
        for key in self.Comps:
            self.Comps[key].state(self.nodes)
            
    def cycleFdot(self):
    
        i = 0
        while (self.fdotok == False):
            curfdotok = True
            for key in self.Comps:
                self.Comps[key].fdot(self.nodes)
                curfdotok = curfdotok and self.Comps[key].fdotok
            i = i + 1
            if (i > 20 or curfdotok == True):
                self.fdotok = True
    
    def cycleSimulator(self):
        for key in self.Comps:
            self.Comps[key].simulate(self.nodes)

        self.totalworkExtracted = 0
        self.totalworkRequired = 0
        self.totalheatAdded = 0
        for key in self.Comps:
            self.Comps[key].simulate(self.nodes)
            if self.Comps[key].energy == "workExtracted":
                self.totalworkExtracted += self.Comps[key].workExtracted
            if self.Comps[key].energy == "workRequired":
                self.totalworkRequired += self.Comps[key].workRequired
            if self.Comps[key].energy == "heatAdded":
                self.totalheatAdded += self. Comps[key].heatAdded

            
        self.netpoweroutput = self.totalworkExtracted - self.totalworkRequired
        self.efficiency = 100.0 * self.netpoweroutput / self.totalheatAdded
        self.HeatRate = 3600.0 / (self.efficiency * 0.01)
        self.SteamRate = self.HeatRate / self.totalheatAdded

    def SpecifiedNetOutputPowerSimulator(self, Wcycledot):
        self.Wcycledot = Wcycledot
        self.mdot = self.Wcycledot * self.SteamRate * 1000.0
        
        for i in range(self.NodeNum):
            self.nodes[i].calmdot(self.mdot)
       
            
        self.totalWExtracted = 0
        self.totalWRequired = 0
        self.totalQAdded = 0
        for key in self.Comps:
            self.Comps[key].sm_energy(self.nodes)
            if self.Comps[key].energy == "workExtracted":
                self.totalWExtracted += self.Comps[key].WExtracted
            if self.Comps[key].energy == "workRequired":
                self.totalWRequired += self.Comps[key].WRequired
            if self.Comps[key].energy == "heatAdded":
                self.totalQAdded += self. Comps[key].QAdded
    
    
    def SpecifiedMassFlowSimulator(self, mdot):
        self.mdot = mdot
        self.Wcycledot = self.mdot * self.netpoweroutput / (1000.0 * 3600.0)

        for i in range(self.NodeNum):
            self.nodes[i].calmdot(self.mdot)
        
        self.totalWExtracted=0
        self.totalWRequired=0
        self.totalQAdded=0 
        for key in self.Comps:
            self.Comps[key].sm_energy(self.nodes)
            if self.Comps[key].energy == "workExtracted":
                self.totalWExtracted += self.Comps[key].WExtracted
            if self.Comps[key].energy == "workRequired":
                self.totalWRequired += self.Comps[key].WRequired
            if self.Comps[key].energy == "heatAdded":
                self.totalQAdded += self. Comps[key].QAdded                 

    def OutFiles(self, outfilename=None):
         savedStdout = sys.stdout  
         if (outfilename!=None):
            datafile = open(outfilename, 'w', encoding='utf-8')
            sys.stdout = datafile 

         print("\n  \t%s" %self.name)
         print("{:>20} {:>.2f}".format('Net Power(MW)', self.Wcycledot))
         print("{:>20} {:>.2f}".format('Mass Flow(kg/h)', self.mdot))
         print("{:>20} {:>.2f}".format('Efficiency(%)', self.efficiency))
         print("{:>20} {:>.2f}".format('Heat Rate(kJ/kWh)', self.HeatRate))
         print("{:>20} {:>.2f}".format('Steam Rate(kg/kWh)', self.SteamRate))

         print("{:>20} {:>.2f}".format('totalWExtracted(MW)',self.totalWExtracted))
         print("{:>20} {:>.2f}".format('totalWRequired(MW)', self.totalWRequired))
         print("{:>20} {:>.2f} \n".format('totalQAdded(MW)', self.totalQAdded))

         print(Node.nodetitle)
         for node in self.nodes:
             print(node)
         for key in self.Comps:
             print(self.Comps[key].export(self.nodes))
        
         if (outfilename!=None):
            datafile.close() 
            sys.stdout = savedStdout 
            
            
class SimRankineCycle(object):

    def __init__(self, nodes_filesname, dev_filesname):
        self.nodes_filesname = nodes_filesname
        self.dev_filesname = dev_filesname
        self.cyclename = nodes_filesname[0:nodes_filesname.find('-')]

    def CycleSimulator(self):
        self.cycle = RankineCycle(self.cyclename)
        self.cycle.addNodes(self.nodes_filesname)
        self.cycle.addComponent(self.dev_filesname)
        self.cycle.componentState()
        self.cycle.cycleFdot()
        self.cycle.cycleSimulator()

    def SpecifiedNetOutputPowerSimulatorAndOutput(self, Wcycledot):
        """ Specified Net Output Power"""
        self.cycle.SpecifiedNetOutputPowerSimulator(Wcycledot)
        # output
        self.cycle.OutFiles()
        self.cycle.OutFiles(self.cyclename + '-SP.txt')

    def SpecifiedMassFlowSimulatorAndOutput(self, mdot):
        """ Specified Mass Flow"""
        self.cycle.SpecifiedMassFlowSimulator(mdot)
        # output
        self.cycle.OutFiles()
        

    







