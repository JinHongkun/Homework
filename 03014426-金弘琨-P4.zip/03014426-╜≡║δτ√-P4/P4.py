import matplotlib.pyplot as plt
import numpy as np

def getData(fileName):
    dataFile = open(fileName, 'r')
    X0 = []
    Y0 = []
    X1 = []
    Y1 = []
    X2 = []
    Y2 = []
    X3 = []
    Y3 = []
    discardHeader = dataFile.readline()
    for line in dataFile:
        x0, y0, x1, y1, x2, y2, x3, y3 = line.split('	')
        X0.append(float(x0))
        Y0.append(float(y0))
        X1.append(float(x1))
        Y1.append(float(y1))
        X2.append(float(x2))
        Y2.append(float(y2))
        X3.append(float(x3))
        Y3.append(float(y3))
    dataFile.close()
    return (X0, Y0, X1, Y1, X2, Y2, X3, Y3)

def plotData(X, Y):
    X=np.array(X)
    Y=np.array(Y)
    plt.plot(X,Y,'bo',
               label = '(x,y)')
    a,b= np.polyfit(X, Y, 1)
    predictedY=a*np.array(X)+b
    k=a
    plt.plot(X,predictedY,label='Y predicted by\nlinear fit,k='+str(round(k,5)))
    plt.legend(loc='best')

def average(X):
    ave=round(np.mean(X),2)
    return ave

def variance(X):
    var=round(np.var(X),2)
    return var
        
def correlation(X,Y):
    cor=np.corrcoef(X,Y)
    return cor


inputFile='DATA.txt'

X0, Y0, X1, Y1, X2, Y2, X3, Y3 = getData(inputFile)

fig0 = plt.figure('fig0')
plotData(X0,Y0)
fig1 = plt.figure('fig1')
plotData(X1,Y1)
fig2 = plt.figure('fig2')
plotData(X2,Y2)
fig3 = plt.figure('fig3')
plotData(X3,Y3)

aveX0=average(X0)
aveX1=average(X1)
aveX2=average(X2)
aveX3=average(X3)
aveY0=average(Y0)
aveY1=average(Y1)
aveY2=average(Y2)
aveY3=average(Y3)
varX0=variance(X0)
varX1=variance(X1)
varX2=variance(X2)
varX3=variance(X3)
varY0=variance(Y0)
varY1=variance(Y1)
varY2=variance(Y2)
varY3=variance(Y3)
cor0=correlation(X0,Y0)
cor1=correlation(X1,Y1)
cor2=correlation(X2,Y2)
cor3=correlation(X3,Y3)

print('----------')
print ('AVERAGE')
print('----------')
print ('aveX0=',aveX0)
print ('aveY0=',aveY0)
print ('aveX1=',aveX1)
print ('aveY1=',aveY1)
print ('aveX2=',aveX2)
print ('aveY2=',aveY2)
print ('aveX3=',aveX3)
print ('aveY3=',aveY3)
print('----------')
print ('VARIANCE')
print('----------')
print ('varX0=',varX0)
print ('varY0=',varY0)
print ('varX1=',varX1)
print ('varY1=',varY1)
print ('varX2=',varX2)
print ('varY2=',varY2)
print ('varX3=',varX3)
print ('varY3=',varY3)
print('-----------------------------')
print('CORRELATION:')
print('-----------------------------')
print('cor0=',cor0)
print('cor1=',cor1)
print('cor2=',cor2)
print('cor3=',cor3)




plt.show()




