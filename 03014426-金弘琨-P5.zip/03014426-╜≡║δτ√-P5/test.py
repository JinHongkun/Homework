import unittest
from _Backward3x_v_PT import _Backward3x_v_PT


class mytest(unittest.TestCase):
    
    def setUp(self):
        self.a={'p1':22.0,'t1':646.89,'p2':22.064,'t2':647.15}
        
    def test_Backward3x_v_PT(self):
        self.assertAlmostEqual(_Backward3x_v_PT(self.a['p1'],self.a['t1']),3.798732962e-3)
        self.assertAlmostEqual(_Backward3x_v_PT(self.a['p2'],self.a['t2']),3.701940010e-3)

      



        
if __name__ =='__main__':
  unittest.main()


    
