#include<iostream>
using namespace std;
int main(void){

	cout<<"hello world"<<endl;
	
	
	
	} 
