#include<iostream>
#include"calP.h"
#include"calT.h"
using namespace std;	
int main(void){
	float T,P;
	cout<<"please input T\n";
	cin>>T;
	cout<<calP(T)<<endl;
	cout<<"please input P\n";
	cin>>P;
	cout<<calT(P)<<endl;
	
	
	
	} 
