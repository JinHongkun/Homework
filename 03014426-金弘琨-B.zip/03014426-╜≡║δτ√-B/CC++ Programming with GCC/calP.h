float calP (float );
