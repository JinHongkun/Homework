float calT(float );
